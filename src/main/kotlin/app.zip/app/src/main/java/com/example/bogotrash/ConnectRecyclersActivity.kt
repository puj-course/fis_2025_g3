package com.example.bogotrash

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.bogotrash.databinding.ActivityRecyclerConnectionBinding
import com.example.bogotrash.model.Recycler

class ConnectRecyclersActivity : AppCompatActivity() {

    private lateinit var binding: ActivityRecyclerConnectionBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRecyclerConnectionBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Datos simulados (reemplazar con datos de la base de datos)
        val recyclers = listOf(
            Recycler(1, "Juan Pérez", "3001234567", "Calle 123 #45-67", "Usaquén"),
            Recycler(2, "María Gómez", "3109876543", "Avenida 68 #12-34", "Chapinero"),
            Recycler(3, "Carlos Rodríguez", "3204567890", "Carrera 7 #89-01", "Suba")
        )

        // Configurar RecyclerView
        binding.recyclerViewRecyclers.apply {
            layoutManager = LinearLayoutManager(this@ConnectRecyclersActivity)
            adapter = RecyclerAdapter(recyclers)
        }

        // Código comentado para conectar con la base de datos cuando esté lista
        /*
        val databaseConnection = DatabaseConnection(this)
        val recyclersFromDb = databaseConnection.getRecyclers()
        binding.recyclerViewRecyclers.apply {
            layoutManager = LinearLayoutManager(this@ConnectRecyclersActivity)
            adapter = RecyclerAdapter(recyclersFromDb)
        }
        */
    }
}